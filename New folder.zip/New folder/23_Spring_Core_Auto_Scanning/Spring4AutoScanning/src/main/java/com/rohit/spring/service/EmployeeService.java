package com.rohit.spring.service;

import com.rohit.spring.model.Employee;

public interface EmployeeService {

	void registerEmployee(Employee employee);
}

