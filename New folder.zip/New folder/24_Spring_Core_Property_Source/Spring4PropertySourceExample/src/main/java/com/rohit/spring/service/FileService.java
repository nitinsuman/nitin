package com.rohit.spring.service;

public interface FileService {

	void readValues();
}
