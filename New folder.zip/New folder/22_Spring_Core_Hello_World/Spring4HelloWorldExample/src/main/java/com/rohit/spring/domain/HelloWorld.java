package com.rohit.spring.domain;

public interface HelloWorld {

	void sayHello(String name);
}
